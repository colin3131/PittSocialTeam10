create function a_removeuserfrompendingfriends() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM pendingfriend fr
    WHERE OLD.userID=fr.fromid or OLD.userID=fr.toid;
    RETURN OLD;
END;
$$;

alter function a_removeuserfrompendingfriends() owner to postgres;

