create function removeuserfrommessagerecipient() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM messageRecipient mr
    WHERE OLD.userID=mr.userID;
    RETURN OLD;
END;
$$;

alter function removeuserfrommessagerecipient() owner to postgres;

