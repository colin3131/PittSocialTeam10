create function checkgroupmembers() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT FROM groupMember gm
        WHERE new.gID=gm.gID
          AND new.userID=gm.userID
    ) THEN
        RAISE EXCEPTION 'user already in group';
        return null;
    ELSE
        return new;
    END IF;
END;
$$;

alter function checkgroupmembers() owner to postgres;

