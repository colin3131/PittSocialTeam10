create function addrecipient() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO messageRecipient
        VALUES(new.msgID, new.toUserID);
    RETURN new;
END;
$$;

alter function addrecipient() owner to postgres;

