create procedure pro_update_last_read(input_sensor_id integer, read_time timestamp without time zone)
    language plpgsql
as
$$
begin
    update sensor as s
    set last_read = read_time
    where s.sensor_id = input_sensor_id;
end;
$$;

alter procedure pro_update_last_read(integer, timestamp) owner to postgres;

