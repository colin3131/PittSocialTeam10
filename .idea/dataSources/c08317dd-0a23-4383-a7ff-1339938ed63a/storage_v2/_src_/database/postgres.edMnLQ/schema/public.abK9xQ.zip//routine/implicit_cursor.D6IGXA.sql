create procedure implicit_cursor()
    language plpgsql
as
$$
declare
    forest_rec forest%rowtype;
begin
    for forest_rec in
        select *
        from forest
    loop
        raise notice '%', forest_rec.name;
    end loop;
end;
$$;

alter procedure implicit_cursor() owner to postgres;

