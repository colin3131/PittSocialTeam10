create function wrap_search(strings text[])
    returns TABLE(userna character varying, userem character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT usern, usere FROM search_user(strings);
end;
$$;

alter function wrap_search(text[]) owner to postgres;

