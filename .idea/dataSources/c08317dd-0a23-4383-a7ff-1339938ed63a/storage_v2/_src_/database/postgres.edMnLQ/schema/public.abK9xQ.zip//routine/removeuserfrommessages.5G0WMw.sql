create function removeuserfrommessages() returns trigger
    language plpgsql
as
$$
DECLARE
    -- Grab all of the message ids where it's from the user, to the user, or to the user's group
    cur_relatedmsg CURSOR(uid INTEGER) FOR
                    SELECT msgid
                    FROM messageinfo mi
                    WHERE mi.fromid=uid
                       OR mi.touserid=uid
                       OR mi.togroupid in (
                           SELECT gid
                           FROM groupmember gm
                           WHERE userid=uid
                        );
    rec_msg RECORD;
BEGIN
    OPEN cur_relatedmsg(OLD.userid);
    LOOP
        FETCH cur_relatedmsg into rec_msg;
        EXIT WHEN NOT FOUND;
        IF NOT EXISTS(SELECT FROM messagerecipient mr
                        WHERE mr.msgid = rec_msg.msgid) -- If there's no message recipients left
                  AND(SELECT fromid FROM messageinfo mi -- and there's no sender left
                        WHERE mi.msgid = rec_msg.msgid) IS NULL THEN
            -- Then delete the message
            DELETE FROM messageinfo mi WHERE mi.msgid=rec_msg.msgid;
        ELSEIF EXISTS(SELECT FROM messageinfo mi
                        WHERE mi.fromid=OLD.userid AND mi.msgid=rec_msg.msgid)THEN
            UPDATE messageinfo SET fromid=null WHERE fromid=OLD.userid AND msgid=rec_msg.msgid;
            IF NOT EXISTS(SELECT FROM messagerecipient mr
                        WHERE mr.msgid = rec_msg.msgid) THEN
                DELETE FROM messageinfo mi WHERE mi.msgid=rec_msg.msgid;
            end if;
        ELSEIF EXISTS(SELECT FROM messageinfo mi
                        WHERE mi.touserid=OLD.userid AND mi.msgid=rec_msg.msgid)THEN
            UPDATE messageinfo SET touserid=null WHERE touserid=OLD.userid AND msgid=rec_msg.msgid;
            IF NOT EXISTS(SELECT FROM messagerecipient mr
                        WHERE mr.msgid = rec_msg.msgid) THEN
                DELETE FROM messageinfo mi WHERE mi.msgid=rec_msg.msgid;
            end if;
        end if;
    end loop;
    CLOSE cur_relatedmsg;
    RETURN OLD;
END;
$$;

alter function removeuserfrommessages() owner to postgres;

