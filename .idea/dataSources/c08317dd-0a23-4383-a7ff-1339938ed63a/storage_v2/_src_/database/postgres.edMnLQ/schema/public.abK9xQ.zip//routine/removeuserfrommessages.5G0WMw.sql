create function removeuserfrommessages() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM messageInfo mi
    WHERE OLD.userID=mi.fromID or OLD.userID=mi.toUserID;
    RETURN OLD;
END;
$$;

alter function removeuserfrommessages() owner to postgres;

