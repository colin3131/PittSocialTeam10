create function groupmember_over_limit() returns trigger
    language plpgsql
as
$$
DECLARE
    ilimit integer := (SELECT size
                        FROM groupInfo g
                        WHERE NEW.gID=g.gID);
    imembers integer := (SELECT count(*)
                            FROM groupMember gm
                            WHERE NEW.gID=gm.gID);
BEGIN
    IF imembers < ilimit THEN
        return NEW;
    ELSE
        RAISE EXCEPTION 'group is already at limit';
        return NULL;
    END IF;
END;
$$;

alter function groupmember_over_limit() owner to postgres;

