create function pendinggroupmember_check() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT FROM pendingGroupMember pgm
                WHERE new.gID=pgm.gID
                AND new.userID=pgm.userID) THEN
        DELETE FROM pendingGroupMember pgm
            WHERE new.gID=pgm.gID
              AND new.userID=pgm.userID;
    end if;
    return new;
END;
$$;

alter function pendinggroupmember_check() owner to postgres;

