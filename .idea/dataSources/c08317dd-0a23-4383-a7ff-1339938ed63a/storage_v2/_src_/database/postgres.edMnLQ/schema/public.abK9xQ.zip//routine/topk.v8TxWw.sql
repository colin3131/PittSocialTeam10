create function topk(prof integer, x timestamp without time zone, k integer)
    returns TABLE(profile integer, fromcount bigint, tocount bigint)
    language plpgsql
as
$$
DECLARE
    BEGIN
        RETURN QUERY SELECT fromid as profile, count(fromid) AS fromCount, CAST(0 as bigint)  as toCount FROM messageinfo WHERE touserid=prof AND timesent>x GROUP BY fromid ORDER BY fromCount DESC LIMIT k;
        RETURN QUERY SELECT touserid as profile, CAST(0 as bigint) as fromCount, count(touserid) AS toCount  FROM messageinfo WHERE fromid=prof AND timesent>x GROUP BY touserid ORDER BY toCount DESC LIMIT k;
        RETURN;
    END;
$$;

alter function topk(integer, timestamp, integer) owner to postgres;

