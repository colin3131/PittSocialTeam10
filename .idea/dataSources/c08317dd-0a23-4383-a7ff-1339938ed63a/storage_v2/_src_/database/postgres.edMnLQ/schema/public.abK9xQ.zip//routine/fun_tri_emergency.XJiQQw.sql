create function fun_tri_emergency() returns trigger
    language plpgsql
as
$$
begin
    if new.temperature > 100 then
        insert into emergency
            values(new.sensor_id, new.report_time);
    end if;
    return new;
end;
$$;

alter function fun_tri_emergency() owner to postgres;

