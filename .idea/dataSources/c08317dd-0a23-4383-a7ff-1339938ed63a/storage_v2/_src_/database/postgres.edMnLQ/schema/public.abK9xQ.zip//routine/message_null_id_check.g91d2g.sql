create function message_null_id_check() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.toUserID IS NULL AND NEW.toGroupID IS NOT NULL THEN
        return NEW;
    ELSIF NEW.toUserID IS NOT NULL AND NEW.toGroupID IS NULL THEN
        return NEW;
    ELSE
        RETURN NULL;
    END IF;
END;
$$;

alter function message_null_id_check() owner to postgres;

