create procedure explicit_cursor()
    language plpgsql
as
$$
declare
    f_cursor cursor for select * from forest;
    forest_rec forest%rowtype;
begin
    open f_cursor;
    loop
        fetch f_cursor into forest_rec;
        exit when not found;
        raise notice '%', forest_rec.name;
    end loop;
    close f_cursor;
end;
$$;

alter procedure explicit_cursor() owner to postgres;

