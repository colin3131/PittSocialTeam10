create function removeuserfromgroups() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM groupMember gm
    WHERE NEW.userID=gm.userID;
    RETURN NEW;
END;
$$;

alter function removeuserfromgroups() owner to postgres;

