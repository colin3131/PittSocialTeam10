create function removeuserfromgroups() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM groupMember gm
    WHERE OLD.userID=gm.userID;
    RETURN OLD;
END;
$$;

alter function removeuserfromgroups() owner to postgres;

