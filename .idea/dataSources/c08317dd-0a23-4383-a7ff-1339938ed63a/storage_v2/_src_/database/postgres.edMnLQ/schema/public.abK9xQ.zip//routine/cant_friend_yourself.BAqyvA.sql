create function cant_friend_yourself() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.fromID=NEW.toID THEN
        RAISE EXCEPTION 'cannot friend yourself';
        return null;
    ELSE
        return new;
    end if;
END;
$$;

alter function cant_friend_yourself() owner to postgres;

