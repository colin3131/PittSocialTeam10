create function a_removeuserfromfriends() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM friend fr
    WHERE OLD.userID=fr.userID1 or OLD.userID=fr.userID2;
    RETURN OLD;
END;
$$;

alter function a_removeuserfromfriends() owner to postgres;

