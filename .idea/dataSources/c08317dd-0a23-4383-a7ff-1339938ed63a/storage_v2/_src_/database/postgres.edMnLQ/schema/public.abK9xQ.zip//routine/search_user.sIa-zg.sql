create function search_user(strings text[])
    returns TABLE(username character varying, useremail character varying)
    language plpgsql
as
$$
DECLARE
        str text := 'test';
        i int := 1;
    BEGIN
        str := strings[i];
        WHILE str is not NULL
        LOOP
            str := strings[i];
            RETURN QUERY SELECT name as username,email as useremail FROM profile where name LIKE '%' || strings[i] || '%' or email LIKE '%' || strings[i] || '%';
            i := i + 1;
        end loop;
        RETURN;
    END;
$$;

alter function search_user(text[]) owner to postgres;

