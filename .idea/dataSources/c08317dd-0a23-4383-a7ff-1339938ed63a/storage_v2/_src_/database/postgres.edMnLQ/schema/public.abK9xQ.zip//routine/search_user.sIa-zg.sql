create function search_user(strings text[])
    returns TABLE(usern character varying, usere character varying)
    language plpgsql
as
$$
DECLARE
        str text := 'test';
        i int := 1;
--         rec record;
--         cur_prof cursor(sub text)
--             for SELECT name as username,email as useremail FROM profile where name LIKE '%' || sub || '%' or email LIKE '%' || sub || '%';
    BEGIN
            str := strings[1];
            WHILE str is not NULL
            LOOP
            str := strings[i];
    --             OPEN cur_prof(strings[i]);
    --             LOOP
    --                 FETCH cur_prof into rec;
    --                 EXIT WHEN rec IS NULL;
            RAISE NOTICE 'CHECKING STRING';
            RAISE NOTICE 'Yo the current string is: %', strings[i];
            RETURN QUERY SELECT name as username,email as useremail FROM profile where name LIKE '%' || strings[i] || '%' or email LIKE '%' || strings[i] || '%';
    --             END LOOP;
    --             close cur_prof;
                i := i + 1;
            end loop;
            RAISE NOTICE 'DONE LOOPING';
            RETURN;
    END;
$$;

alter function search_user(text[]) owner to postgres;

