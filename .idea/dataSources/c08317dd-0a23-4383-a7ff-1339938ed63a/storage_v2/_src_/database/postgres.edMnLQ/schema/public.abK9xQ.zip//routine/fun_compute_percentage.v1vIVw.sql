create function fun_compute_percentage(input_forest_no character varying, area_covered double precision) returns double precision
    language plpgsql
as
$$
declare
    percent_covered float;
begin
    select area_covered/area
    into percent_covered
    from forest
    where forest_no = input_forest_no;
    if percent_covered > 1 then
        percent_covered := 1;
    end if;
    return percent_covered;
end;
$$;

alter function fun_compute_percentage(varchar, double precision) owner to postgres;

