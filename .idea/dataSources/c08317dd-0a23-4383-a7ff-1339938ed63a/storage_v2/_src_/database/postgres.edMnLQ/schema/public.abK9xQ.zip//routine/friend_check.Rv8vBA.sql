create function friend_check() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT FROM friend f
                WHERE new.userID1=f.userID2
                    AND new.userID2=f.userID1) THEN
        RAISE EXCEPTION 'users are already friends';
        return null;
    ELSE
        return new;
    END IF;
END;
$$;

alter function friend_check() owner to postgres;

