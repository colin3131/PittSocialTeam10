create function addgrouprecipient() returns trigger
    language plpgsql
as
$$
DECLARE
    cur_groupMembers CURSOR(grID INTEGER) FOR SELECT userID
                                FROM groupMember gm
                                WHERE gm.gID=grID;
    rec_groupMember RECORD;
BEGIN
    OPEN cur_groupMembers(NEW.toGroupID);
    LOOP
        FETCH cur_groupMembers INTO rec_groupMember;
        EXIT WHEN NOT FOUND;

        INSERT INTO messageRecipient VALUES(NEW.msgID, rec_groupMember.userID);

    END LOOP;
    CLOSE cur_groupMembers;
    RETURN NEW;
END;
$$;

alter function addgrouprecipient() owner to postgres;

