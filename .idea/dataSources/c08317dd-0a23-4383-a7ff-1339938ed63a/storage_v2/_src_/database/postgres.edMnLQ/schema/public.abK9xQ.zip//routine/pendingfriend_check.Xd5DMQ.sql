create function pendingfriend_check() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT FROM pendingFriend p
                WHERE new.userID1=p.toID
                    AND new.userID2=p.fromID) THEN

        DELETE FROM pendingFriend p
            WHERE new.userID1=p.toID
            AND new.userID2=p.fromID;

    ELSIF EXISTS (SELECT FROM pendingFriend p
                    WHERE new.userID1=p.fromID
                    AND new.userID2=p.toID) THEN

        DELETE FROM pendingFriend p
            WHERE new.userID1=p.fromID
            AND new.userID2=p.toID;
    end if;
    return new;
END;
$$;

alter function pendingfriend_check() owner to postgres;

