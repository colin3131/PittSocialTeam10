create function fun_tri_percentage() returns trigger
    language plpgsql
as
$$
begin
    if new.area <> old.area then
        new.percentage := fun_Compute_Percentage(new.forest_no,
                                                new.area);
    end if;
    return new;
end;
$$;

alter function fun_tri_percentage() owner to postgres;

