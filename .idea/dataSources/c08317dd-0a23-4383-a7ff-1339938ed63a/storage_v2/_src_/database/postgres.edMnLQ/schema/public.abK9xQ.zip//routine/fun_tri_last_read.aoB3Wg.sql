create function fun_tri_last_read() returns trigger
    language plpgsql
as
$$
begin
    call pro_Update_Last_Read(new.sensor_id,
                            new.report_time);
    return new;
end;
$$;

alter function fun_tri_last_read() owner to postgres;

