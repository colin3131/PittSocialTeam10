create function friend_already_check() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT FROM friend f
                WHERE f.userID1=new.fromID
                    AND f.userID2=new.toID
                     OR f.userID1=new.toID
                    AND f.userID2=new.fromID) THEN
        return null;
    ELSE
        return new;
    end if;
END;
$$;

alter function friend_already_check() owner to postgres;

